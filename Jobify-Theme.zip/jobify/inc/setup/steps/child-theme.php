<p><?php _e( 'While optional, using a child theme with Jobify allows an easy way to customize your website without having to worry about changes being overwritten when you update in the future', 'jobify' ); ?></p>

<p><?php _e( 'To edit these included files you can visit <strong>Appearance &rarr; Editor</strong> in your WordPress dashboard. You may also edit the files by accessing your web server via FTP.', 'jobify' ); ?></p>

<p><a href="javascript:;" class="uct-activate button button-primary"><?php _e( 'Create and Activate a Child Theme', 'jobify' ); ?></a></p>

<div class="uct-notice"><p></p></div>
